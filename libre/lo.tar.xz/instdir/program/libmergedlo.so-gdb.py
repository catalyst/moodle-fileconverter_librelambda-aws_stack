# -*- tab-width: 4; indent-tabs-mode: nil; py-indent-offset: 4 -*-
#
# This file is part of the LibreOffice project.
#
# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#

import importlib
import os.path
import sys

import gdb

PP_PATH = os.path.normpath('/lo/libreoffice-7.3.2.2/solenv/gdb')

if gdb.current_objfile():
    if PP_PATH not in sys.path:
        sys.path.insert(0, PP_PATH)

for mod in 'svl tl basegfx vcl utl'.split():
    module = importlib.import_module('libreoffice.' + mod)
    module.register_pretty_printers(gdb.current_objfile())

try:
    import boost
    boost.register_pretty_printers(gdb)
except:
    pass

# vim:set filetype=python shiftwidth=4 softtabstop=4 expandtab:
